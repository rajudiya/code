<?php
namespace rohan\login\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Customer\Model\Session;
use Magento\Framework\App\ResponseFactory;
use Magento\Framework\UrlInterface;

class Redirect implements ObserverInterface
{

    protected $_responseFactory;
    protected $_url;
    protected $_session;

    public function __construct(Session $session,ResponseFactory $responseFactory,UrlInterface $url) 
    {
        $this->_session = $session;
        $this->_responseFactory = $responseFactory;
        $this->_url = $url;
    }

    public function execute(Observer $observer)
    {

        $isCustomerLoggedIn = $this->_session->isLoggedIn();
        $data = $observer->getItemsCount();

        if ($isCustomerLoggedIn) {
            $event = $observer->getEvent()->getBlock();
            $CustomRedirectionUrl = $this->_url->getUrl('checkout/cart');
            $this->_session->setBeforeAuthUrl($CustomRedirectionUrl);
            return $this;

            /* add your Logic here*/
        }
    }
}