<?php
namespace rohan\order\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class OrderPlaceBefore implements ObserverInterface
{
    public function execute(Observer $observer)
    {

        $displayText = $observer->getData();
        echo $displayText->getText() . " - Event </br>";
        $displayText->setText('Execute event successfully.');
        return $this;

        /* add your Logic here*/
    }
}