<?php
namespace rohan\order\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class OrderCancel implements ObserverInterface
{
    public function execute(Observer $observer)
    {

        print_r($observer->getEvent()->getItem());
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/Mylogfile.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $logger->info("PRoduct file iniciated ....".$observer);


        /* add your Logic here*/
    }
}