<?php
namespace rohan\wishlist\Plugin;

use Magento\Catalog\Helper\Product\Configuration;
use Magento\Catalog\Model\Product\Configuration\Item\ItemInterface;
class QuotePlugin
{
    public function aroundGetCustomOptions(Configuration $subject,callable $proceed,ItemInterface $item
    ) {
        //echo "<h1>HELLOW</h1>";
        $result = $proceed($item);
        $result[] = [
            'label' => 'Custom Label',
            'value' => 'Rohan Ajudiya'
        ];
        return $result;
    }
}