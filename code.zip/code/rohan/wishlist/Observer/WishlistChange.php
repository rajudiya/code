<?php
namespace rohan\wishlist\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
class wishlistChange implements ObserverInterface
{
    public function execute(Observer $observer) 
    {
        $data = $observer->getData('items');
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/Mylogfile.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $logger->info("PRoduct file iniciated ....".$data);

        /* add your Logic here*/
    }

}
