<?php

namespace Magento\Users\Model;

class UsersModel extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case.
     */
    const PRODUCT_ID = 'user_id ';
    const PRODUCT_NAME = 'firstname';
    const SKU = 'email';
    const QUANTITY = 'username ';
    const PRICE = 'password';
    const CREATED_AT = 'created';
    
    /**
     * CMS page cache tag.
     */
    const CACHE_TAG = 'all_products_records';

    /**
     * @var string
     */
    protected $_cacheTag = 'all_products_records';

    /**
     * Prefix of model events names.
     *
     * @var string
     */
    protected $_eventPrefix = 'all_products_records';

    /**
     * Initialize resource model.
     */
    protected function _construct()
    {
        $this->_init('Magento\Users\Model\ResourceModel\UsersModel');
    }
    /**
     * Get ProductId.
     *
     * @return int
     */
    public function getProductId()
    {
        return $this->getData(self::PRODUCT_ID);
    }

    /**
     * Set ProductId.
     *
     * @param int $productId
     * @return void
     */
    public function setProductId($productId)
    {
        return $this->setData(self::PRODUCT_ID, $productId);
    }

    /**
     * Get ProductName.
     *
     * @return varchar
     */
    public function getProductName()
    {
        return $this->getData(self::PRODUCT_NAME);
    }

    /**
     * Set ProductName.
     *
     * @param int $productName
     * @return varchar
     */
    public function setProductName($productName)
    {
        return $this->setData(self::PRODUCT_NAME, $productName);
    }

    /**
     * Get Sku.
     *
     * @return varshar
     */
    public function getSku()
    {
        return $this->getData(self::SKU);
    }

    /**
     * Set Sku.
     *
     * @param int $sku
     * @return void
     */
    public function setSku($sku)
    {
        return $this->setData(self::SKU, $sku);
    }
    
    /**
     * Get CreatedAt.
     *
     * @return varchar
     */
    public function getQuantity()
    {
        return $this->getData(self::QUANTITY);
    }

    /**
     * Set Quantity.
     *
     * @param int $quantity
     * @return void
     */
    public function setQuantity($quantity)
    {
        return $this->setData(self::QUANTITY, $quantity);
    }

    /**
     * Get Price.
     *
     * @return varchar
     */
    public function getPrice()
    {
        return $this->getData(self::PRICE);
    }

    /**
     * Set Price.
     *
     * @param int $price
     * @return void
     */
    public function setPrice($price)
    {
        return $this->setData(self::PRICE, $price);
    }
    /**
     * Get CreatedAt.
     *
     * @return varchar
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * Set CreatedAt.
     *
     * @param int $createdAt
     * @return void
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }
}
