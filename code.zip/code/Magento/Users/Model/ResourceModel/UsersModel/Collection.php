<?php

namespace Magento\Users\Model\ResourceModel\UsersModel;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'user_id';

    /**
     * Define resource model
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            'Magento\Users\Model\UsersModel',
            'Magento\Users\Model\ResourceModel\UsersModel'
        );
    }
}
