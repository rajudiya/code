<?php

namespace Main\Product\Model\ResourceModel\ProductModel;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'product_id';

    /**
     * Define resource model
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            'Main\Product\Model\ProductModel',
            'Main\Product\Model\ResourceModel\ProductModel'
        );
    }
}
