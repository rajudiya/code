<?php
 /**
 * Mage_Gift Module Registration
 *
 * @category    Mage
 * @package     Mage_Gift
 * @author      Webkul Software Private Limited
 *
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Mage_Gift',
    __DIR__
);