<?php

namespace Mage\Gift\Model\ResourceModel\GiftModel;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'g_id';

    /**
     * Define resource model
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            'Mage\Gift\Model\GiftModel',
            'Mage\Gift\Model\ResourceModel\GiftModel'
        );
    }
}
