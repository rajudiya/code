<?php

namespace Mage\Gift\Model;

class GiftModel extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case.
     */
    const GIFT_ID = 'gd_id';
    const GIFT_NAME = 'GiftName';
    const Gift_WEIGHT = 'g_weight';
    const CITY = 'g_dispatch_city';
    const CREATED_AT = 'created_at';
    const UPDATE_AT = 'update_at';
    
    /**
     * CMS page cache tag.
     */
    const CACHE_TAG = 'gift_dispatch_records';

    /**
     * @var string
     */
    protected $_cacheTag = 'gift_dispatch_records';

    /**
     * Prefix of model events names.
     *
     * @var string
     */
    protected $_eventPrefix = 'gift_dispatch_records';

    /**
     * Initialize resource model.
     */
    protected function _construct()
    {
        $this->_init('Mage\Gift\Model\ResourceModel\GiftModel');
    }
    /**
     * Get EntityId.
     *
     * @return int
     */
    public function getEntityId()
    {
        return $this->getData(self::GIFT_ID);
    }

    /**
     * Set EntityId.
     *
     * @param int $entityId
     * @return void
     */
    public function setEntityId($entityId)
    {
        return $this->setData(self::GIFT_ID, $entityId);
    }

    /**
     * Get GiftName.
     *
     * @return varchar
     */
    public function getGiftName()
    {
        return $this->getData(self::GIFT_NAME);
    }

    /**
     * Set GiftName.
     *
     * @param int $giftName
     * @return void
     */
    public function setGiftName($giftName)
    {
        return $this->setData(self::GIFT_NAME, $giftName);
    }

    /**
     * Get Gift weight.
     *
     * @return bool
     */
    public function getGiftWeight()
    {
        return $this->getData(self::Gift_WEIGHT);
    }

    /**
     * Set Giftweight.
     *
     * @param int $giftWeight
     * @return void
     */
    public function setGiftWeight($giftWeight)
    {
        return $this->setData(self::Gift_WEIGHT, $giftWeight);
    }

    /**
     * Get Gift City.
     *
     * @return bool
     */
    public function getGiftCity()
    {
        return $this->getData(self::CITY);
    }

    /**
     * Set Gift City.
     *
     * @param int $giftCity
     * @return void
     */
    public function setGiftCity($giftCity)
    {
        return $this->setData(self::CITY, $giftCity);
    }
    
    /**
     * Get CreatedAt.
     *
     * @return varchar
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * Set CreatedAt.
     *
     * @param int $createdAt
     * @return void
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }
     /**
     * Get UpdateAt.
     *
     * @return varchar
     */
    public function getUpdateAt()
    {
        return $this->getData(self::UPDATE_AT);
    }

    /**
     * Set UpdateAt.
     *
     * @param int $updateAt
     * @return void
     */
    public function setUpdateAt($updateAt)
    {
        return $this->setData(self::UPDATE_AT, $updateAt);
    }
}
