<?php

namespace Product\Sticker\Model;
class StickerModel extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case.
     */
    const STICKER_ID = 'sticker_id';
    const USERNAME = 'firstname';
    const STICKER_NAME = 'sticker_name';
    const CREATED_AT = 'created_at';
    const UPDATE_AT = 'updated_at';
    
    /**
     * CMS page cache tag.
     */
    const CACHE_TAG = 'stickers_records';

    /**
     * @var string
     */
    protected $_cacheTag = 'stickers_records';

    /**
     * Prefix of model events names.
     *
     * @var string
     */
    protected $_eventPrefix = 'stickers_records';

    /**
     * Initialize resource model.
     */
    protected function _construct()
    {
        $this->_init('Product\Sticker\Model\ResourceModel\StickerModel');
        $this->_init('Product\Sticker\Model\ResourceModel\StickerModel');
    }
    /**
     * Get ProductId.
     *
     * @return int
     */
    public function getStickerId()
    {
        return $this->getData(self::STICKER_ID);
    }

    /**
     * Set StickerId.
     *
     * @param int $stickerId
     * @return void
     */
    public function setStickerId($stickerId)
    {
        return $this->setData(self::STICKER_ID, $stickerId);
    }
    /**
     * Get admin name.
     *
     * @return varchar
     */
    public function getFirstName()
    {
        return $this->getData(self::USERNAME);
    }

    /**
     * Set StickerName.
     *
     * @param int $stickerName
     * @return varchar
     */
    public function setFirstName($firstName)
    {
        return $this->setData(self::USERNAME, $firstName);
    }

    /**
     * Get StickerName.
     *
     * @return varchar
     */
    public function getStickerName()
    {
        return $this->getData(self::STICKER_NAME);
    }

    /**
     * Set StickerName.
     *
     * @param int $stickerName
     * @return varchar
     */
    public function setStickerName($stickerName)
    {
        return $this->setData(self::STICKER_NAME, $stickerName);
    }
    /**
     * Get CreatedAt.
     *
     * @return varchar
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * Set CreatedAt.
     *
     * @param int $createdAt
     * @return void
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }
    /**
     * Get UpdateAt.
     *
     * @return varchar
     */
    public function getUpdateAt()
    {
        return $this->getData(self::UPDATE_AT);
    }

    /**
     * Set UpdateAt.
     *
     * @param int $updatedAt
     * @return void
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::CREATED_AT, $updatedAt);
    }
}
