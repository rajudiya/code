<?php

namespace Product\Sticker\Model\ResourceModel\StickerModel;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'sticker_id';

    /**
     * Define resource model
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            'Product\Sticker\Model\StickerModel',
            'Product\Sticker\Model\ResourceModel\StickerModel'
        );
    }
}
