<?php
namespace Store\Offer\Ui\Component\Listing;
class CustomerDataProvider extends \Magento\Framework\View\Element\UiComponent\DataProvider\SearchResult
{
   protected function _initSelect()
   {
       parent::_initSelect();
      $this->getSelect()->joinLeft(
        ['secondTable' => $this->getTable('admin_user')],
        'main_table.offer_id = secondTable.user_id',
        '*'
      );
      return $this;
  }
}
?>
