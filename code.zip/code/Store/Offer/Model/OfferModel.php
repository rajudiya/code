<?php

namespace Store\Offer\Model;

class OfferModel extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case.
     */
    const OFFER_ID = 'offer_id';
    const CUSTOMER_ANTITY = 'email';
    const STORE_NAME = 'store_name';
    const STORE_ID = 'store_id';
    const OFFER_NAME = 'offer_name';
    const CREATED_AT = 'created_at';
    const UPDATE_AT = 'updated_at';
    
    /**
     * CMS page cache tag.
     */
    const CACHE_TAG = 'offers_records';
    const CACHE_TAG1 = 'customer_entity_records';

    /**
     * @var string
     */
    protected $_cacheTag = 'offers_records';
    protected $_cacheTag1 = 'customer_entity_records';

    /**
     * Prefix of model events names.
     *
     * @var string
     */
    protected $_eventPrefix = 'offers_records';
    protected $_eventPrefix1 = 'customer_entity_records';

    /**
     * Initialize resource model.
     */
    protected function _construct()
    {
        $this->_init('Store\Offer\Model\ResourceModel\OfferModel');
    }
    /**
     * Get OfferId.
     *
     * @return int
     */
    public function getOfferId()
    {
        return $this->getData(self::OFFER_ID);
    }

    /**
     * Set OfferId.
     *
     * @param int $offerId
     * @return void
     */
    public function setOfferId($offerId)
    {
        return $this->setData(self::OFFER_ID, $offerId);
    }

    /**
     * Get StoreName.
     *
     * @return varchar
     */
    public function getCustomerName()
    {
        return $this->getData(self::CUSTOMER_ANTITY);
    }

    /**
     * Set StoreName.
     *
     * @param int $storeName
     * @return varchar
     */
    public function setCustomerName($customerName)
    {
        return $this->setData(self::CUSTOMER_ANTITY, $customerName);
    }
    /**
     * Get StoreName.
     *
     * @return varchar
     */
    public function getStoreName()
    {
        return $this->getData(self::STORE_NAME);
    }

    /**
     * Set StoreName.
     *
     * @param int $storeName
     * @return varchar
     */
    public function setStoreName($storeName)
    {
        return $this->setData(self::STORE_NAME, $storeName);
    }
    /**
     * Get StoreId.
     *
     * @return int
     */
    public function getStoreId()
    {
        return $this->getData(self::STORE_ID);
    }

    /**
     * Set StoreId.
     *
     * @param int $storeId
     * @return void
     */
    public function setStoreId($storeId)
    {
        return $this->setData(self::STORE_ID, $storeId);
    }

    /**
     * Get OfferName.
     *
     * @return varchar
     */
    public function getOfferName()
    {
        return $this->getData(self::OFFER_NAME);
    }

    /**
     * Set OfferName.
     *
     * @param int $offerName
     * @return varchar
     */
    public function setOfferName($offerName)
    {
        return $this->setData(self::OFFER_NAME, $offerName);
    }
    /**
     * Get CreatedAt.
     *
     * @return varchar
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * Set CreatedAt.
     *
     * @param int $createdAt
     * @return void
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }
    /**
     * Get UpdateAt.
     *
     * @return varchar
     */
    public function getUpdateAt()
    {
        return $this->getData(self::UPDATE_AT);
    }

    /**
     * Set UpdateAt.
     *
     * @param int $updatedAt
     * @return void
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::CREATED_AT, $updatedAt);
    }
    
}
