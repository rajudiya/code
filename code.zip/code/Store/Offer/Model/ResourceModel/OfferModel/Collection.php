<?php

namespace Store\Offer\Model\ResourceModel\OfferModel;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'offer_id';
    protected $_idFieldName1 = 'entity_id';

    /**
     * Define resource model
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            'Store\Offer\Model\OfferModel',
            'Store\Offer\Model\ResourceModel\OfferModel'
        );
    }
}
